const menuIcon = document.querySelector("nav .menu-icon");
const mobileMenuItems = document.querySelector
("nav .mobile-menu-items");

menuIcon.addEventListener("click", () => {
    mobileMenuItems.classList.toggle("active");
});

const tl = gsap.timeline();

tl.from("#hero > img")